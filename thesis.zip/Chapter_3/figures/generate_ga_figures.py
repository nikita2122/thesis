"""Illustrative figures for the standalone GA architecture-optimization chapter."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)


def style(ax):
    ax.tick_params(labelsize=9)
    for s in ax.spines.values():
        s.set_linewidth(0.8)


def fig_chromosome():
    fig, ax = plt.subplots(figsize=(8.4, 2.6), dpi=160)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 3)
    ax.axis("off")
    genes = [
        (0.3, "L", "depth"),
        (1.5, "N1", "neurons"),
        (2.7, "N2", "neurons"),
        (3.9, "N3", "neurons"),
        (5.1, "A1", "act."),
        (6.3, "A2", "act."),
        (7.5, "D1", "drop"),
        (8.7, "D2", "drop"),
    ]
    ax.text(5, 2.6, r"Chromosome $\mathbf{C}$ encoding one MLP classifier", ha="center", fontsize=12)
    for x, lab, sub in genes:
        box = FancyBboxPatch((x, 1.0), 1.0, 0.9, boxstyle="round,pad=0.02,rounding_size=0.08",
                             facecolor="#dbeafe", edgecolor="#1e3a5f", linewidth=1.2)
        ax.add_patch(box)
        ax.text(x + 0.5, 1.55, lab, ha="center", va="center", fontsize=11, fontweight="bold")
        ax.text(x + 0.5, 0.55, sub, ha="center", va="center", fontsize=8, color="#334155")
    ax.annotate("decode", xy=(5.0, 0.15), xytext=(5.0, 0.35),
                ha="center", fontsize=9, color="#9a3412")
    ax.text(5.0, 0.05, r"$\rightarrow$ DNN: 448 $\rightarrow$ hidden stack $\rightarrow$ 8 classes",
            ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(OUT / "fig_chromosome.pdf")
    fig.savefig(OUT / "fig_chromosome.png")
    plt.close(fig)


def fig_crossover():
    fig, axes = plt.subplots(1, 3, figsize=(8.4, 3.2), dpi=160)

    def draw_chrom(ax, title, genes, cut=None, colors=None):
        ax.set_xlim(0, 6)
        ax.set_ylim(0, 3)
        ax.axis("off")
        ax.set_title(title, fontsize=10)
        if colors is None:
            colors = ["#93c5fd"] * len(genes)
        for i, (g, c) in enumerate(zip(genes, colors)):
            x = 0.3 + i * 1.05
            box = FancyBboxPatch((x, 1.1), 0.9, 0.8, boxstyle="round,pad=0.02,rounding_size=0.06",
                                 facecolor=c, edgecolor="#1e3a5f", lw=1.0)
            ax.add_patch(box)
            ax.text(x + 0.45, 1.5, g, ha="center", va="center", fontsize=9, fontweight="bold")
        if cut is not None:
            ax.axvline(0.3 + cut * 1.05, color="#dc2626", ls="--", lw=1.2)
            ax.text(0.3 + cut * 1.05, 2.3, "cut", color="#dc2626", ha="center", fontsize=8)

    draw_chrom(axes[0], r"Parent $\mathbf{C}^{(p)}$", ["3", "256", "128", "64", "R"],
               colors=["#93c5fd"] * 5)
    draw_chrom(axes[1], r"Parent $\mathbf{C}^{(q)}$", ["2", "512", "128", "L", "0.3"],
               colors=["#fcd34d"] * 5)
    draw_chrom(axes[2], r"Child $\mathbf{C}^{(c)}$", ["3", "256", "128", "L", "0.3"],
               cut=2, colors=["#93c5fd", "#93c5fd", "#fcd34d", "#fcd34d", "#fcd34d"])
    fig.suptitle("Single-point crossover: child inherits a prefix from one parent and a suffix from the other",
                 fontsize=10, y=1.02)
    fig.tight_layout()
    fig.savefig(OUT / "fig_crossover.pdf", bbox_inches="tight")
    fig.savefig(OUT / "fig_crossover.png", bbox_inches="tight")
    plt.close(fig)


def fig_fitness_curve():
    rng = np.random.default_rng(7)
    gens = np.arange(0, 51)
    best = 0.62 + 0.30 * (1 - np.exp(-gens / 12.0))
    best += 0.01 * np.cumsum(rng.normal(0, 0.15, size=len(gens))) * 0.02
    best = np.maximum.accumulate(best)
    mean = best - 0.08 - 0.04 * np.exp(-gens / 20) + 0.01 * rng.normal(size=len(gens))
    fig, ax = plt.subplots(figsize=(7.5, 3.4), dpi=160)
    ax.plot(gens, best, color="#9a3412", lw=2.0, label="Best macro-F1")
    ax.plot(gens, mean, color="#1d4ed8", lw=1.5, label="Population mean macro-F1")
    ax.set_xlabel("Generation")
    ax.set_ylabel("Validation macro-F1")
    ax.set_title("Illustrative GA convergence for architecture search")
    ax.set_xlim(0, 50)
    ax.set_ylim(0.55, 0.98)
    ax.legend(frameon=False, fontsize=9)
    ax.grid(True, alpha=0.25)
    style(ax)
    fig.tight_layout()
    fig.savefig(OUT / "fig_ga_convergence.pdf")
    fig.savefig(OUT / "fig_ga_convergence.png")
    plt.close(fig)


def fig_workflow():
    fig, ax = plt.subplots(figsize=(8.2, 4.0), dpi=160)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 6)
    ax.axis("off")
    steps = [
        (1.5, 5.0, "1. Encode\nsearch space"),
        (5.0, 5.0, "2. Init\npopulation"),
        (8.5, 5.0, "3. Evaluate\nmacro-F1"),
        (8.5, 2.8, "4. Select\nparents"),
        (5.0, 2.8, "5. Crossover\n+ mutate"),
        (1.5, 2.8, "6. Elitism\n+ replace"),
        (5.0, 0.8, "7. Terminate\nreturn C*"),
    ]
    for x, y, t in steps:
        box = FancyBboxPatch((x - 1.1, y - 0.55), 2.2, 1.1, boxstyle="round,pad=0.02,rounding_size=0.1",
                             facecolor="#ecfdf5", edgecolor="#065f46", lw=1.2)
        ax.add_patch(box)
        ax.text(x, y, t, ha="center", va="center", fontsize=9)
    arrows = [
        ((2.6, 5.0), (3.9, 5.0)),
        ((6.1, 5.0), (7.4, 5.0)),
        ((8.5, 4.4), (8.5, 3.4)),
        ((7.4, 2.8), (6.1, 2.8)),
        ((3.9, 2.8), (2.6, 2.8)),
        ((1.5, 2.2), (1.5, 1.5)),
        ((1.5, 1.2), (3.9, 0.8)),
    ]
    # loop back from replace to evaluate
    ax.annotate("", xy=(8.5, 4.45), xytext=(1.5, 3.4),
                arrowprops=dict(arrowstyle="->", color="#b45309",
                                connectionstyle="arc3,rad=0.35", lw=1.2))
    ax.text(5.0, 4.0, "repeat generations", ha="center", fontsize=8, color="#b45309")
    for (a, b) in [((2.6, 5), (3.9, 5)), ((6.1, 5), (7.4, 5)), ((8.5, 4.45), (8.5, 3.35)),
                   ((7.4, 2.8), (6.1, 2.8)), ((3.9, 2.8), (2.6, 2.8)), ((1.5, 2.25), (1.5, 1.35)),
                   ((2.6, 0.8), (3.9, 0.8))]:
        ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="->", color="#0f172a", lw=1.1))
    ax.set_title("GA architecture optimization workflow used in this chapter", fontsize=11, pad=8)
    fig.tight_layout()
    fig.savefig(OUT / "fig_ga_workflow.pdf")
    fig.savefig(OUT / "fig_ga_workflow.png")
    plt.close(fig)


def fig_config_specific():
    fig, ax = plt.subplots(figsize=(8.0, 3.0), dpi=160)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")
    configs = [
        (1.5, "Config A", r"$\mathbf{C}_A^*$", "#dbeafe"),
        (5.0, "Config B", r"$\mathbf{C}_B^*$", "#fef3c7"),
        (8.5, "Config C", r"$\mathbf{C}_C^*$", "#fce7f3"),
    ]
    for x, name, out, col in configs:
        box = FancyBboxPatch((x - 1.2, 2.2), 2.4, 1.2, boxstyle="round,pad=0.02,rounding_size=0.1",
                             facecolor=col, edgecolor="#334155", lw=1.1)
        ax.add_patch(box)
        ax.text(x, 2.8, name + "\nGA  ->  " + out,
                ha="center", va="center", fontsize=10)
    ax.text(5, 1.2, "Same GA operators and hyperparameters; different data $\\Rightarrow$ possibly different architectures",
            ha="center", fontsize=9)
    ax.text(5, 0.5, "One-configuration-at-a-time optimization", ha="center", fontsize=11,
            fontweight="bold", color="#9a3412")
    fig.tight_layout()
    fig.savefig(OUT / "fig_config_specific.pdf")
    fig.savefig(OUT / "fig_config_specific.png")
    plt.close(fig)


if __name__ == "__main__":
    fig_chromosome()
    fig_crossover()
    fig_fitness_curve()
    fig_workflow()
    fig_config_specific()
    print("Wrote figures to", OUT)
    for p in sorted(OUT.glob("fig_*.pdf")):
        print(" ", p.name)
