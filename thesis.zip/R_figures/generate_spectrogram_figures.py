"""Generate illustrative vibration signal + spectrogram figures for the standalone chapter."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import gridspec

OUT = Path(__file__).resolve().parent
OUT.mkdir(parents=True, exist_ok=True)

FS = 1200.0
TW = 2.0
TS = 0.25
HOP = 150  # samples
NPERSEG = 300
FMAX = 512.0


def synth_window(t0, alpha_end, fs=FS, tw=TW, seed=0):
    """Synthetic vibration: shaft tone + growing defect tone + noise."""
    n = int(fs * tw)
    t = t0 + np.arange(n) / fs
    rng = np.random.default_rng(seed + int(t0 * 1000))
    # envelope grows within and across windows
    alpha = np.linspace(alpha_end * 0.55, alpha_end, n)
    f0, fd = 30.0, 85.0
    x = (
        0.9 * np.sin(2 * np.pi * f0 * t)
        + 0.35 * np.sin(2 * np.pi * 2 * f0 * t)
        + alpha * np.sin(2 * np.pi * fd * t)
        + 0.12 * rng.standard_normal(n)
    )
    # mild amplitude modulation
    x *= 1.0 + 0.05 * np.sin(2 * np.pi * 2.5 * t)
    return t, x


def log_spectrogram(x, fs=FS, nperseg=NPERSEG, hop=HOP, fmax=FMAX):
    # manual STFT for dependency-light reproducibility
    w = np.hanning(nperseg)
    n = len(x)
    frames = 1 + (n - nperseg) // hop
    specs = []
    for m in range(frames):
        seg = x[m * hop : m * hop + nperseg] * w
        X = np.fft.rfft(seg)
        freqs = np.fft.rfftfreq(nperseg, d=1.0 / fs)
        keep = freqs <= fmax
        specs.append(np.log1p(np.abs(X[keep])))
        freqs = freqs[keep]
    S = np.stack(specs, axis=1)  # F x M
    times = (np.arange(frames) * hop + nperseg / 2) / fs
    return times, freqs, S


def style_ax(ax):
    ax.tick_params(labelsize=9)
    for spine in ax.spines.values():
        spine.set_linewidth(0.8)


def fig1_signal_and_subwindows():
    t, x = synth_window(0.0, alpha_end=0.45, seed=1)
    fig, ax = plt.subplots(figsize=(8.2, 3.2), dpi=160)
    ax.plot(t, x, color="#1f4e79", lw=0.7)
    # mark subwindows
    L = NPERSEG / FS
    starts = np.arange(0, TW - L + 1e-9, HOP / FS)
    for i, s in enumerate(starts):
        ax.axvspan(s, s + L, color="#f4a261" if i % 2 == 0 else "#e9c46a", alpha=0.25, lw=0)
    ax.axvline(starts[0], color="#e76f51", ls="--", lw=1, label="Subwindow boundaries")
    for s in starts[1:]:
        ax.axvline(s, color="#e76f51", ls="--", lw=0.7, alpha=0.7)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Acceleration (a.u.)")
    ax.set_title("Major window vibration signal with overlapping subwindows")
    ax.set_xlim(t[0], t[-1])
    ax.legend(loc="upper right", fontsize=8, frameon=False)
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(OUT / "fig_signal_subwindows.pdf")
    fig.savefig(OUT / "fig_signal_subwindows.png")
    plt.close(fig)


def fig2_spectrogram_current_next():
    t0, x0 = synth_window(0.0, alpha_end=0.40, seed=2)
    t1, x1 = synth_window(TW, alpha_end=0.75, seed=3)
    times0, freqs, S0 = log_spectrogram(x0)
    times1, _, S1 = log_spectrogram(x1)

    fig, axes = plt.subplots(2, 2, figsize=(8.4, 6.2), dpi=160,
                             gridspec_kw={"height_ratios": [1.0, 1.35]})
    # signals
    axes[0, 0].plot(t0, x0, color="#1f4e79", lw=0.65)
    axes[0, 0].set_title(r"Current major window $\mathbf{x}^{(t)}$")
    axes[0, 0].set_ylabel("Acceleration (a.u.)")
    axes[0, 0].set_xlabel("Time (s)")
    axes[0, 1].plot(t1, x1, color="#9b2226", lw=0.65)
    axes[0, 1].set_title(r"Next major window $\mathbf{x}^{(t+1)}$")
    axes[0, 1].set_xlabel("Time (s)")
    for ax in axes[0]:
        style_ax(ax)
        ax.set_xlim(ax.lines[0].get_xdata().min(), ax.lines[0].get_xdata().max())

    vmin = min(S0.min(), S1.min())
    vmax = max(S0.max(), S1.max())
    im0 = axes[1, 0].imshow(
        S0, origin="lower", aspect="auto",
        extent=[times0[0], times0[-1], freqs[0], freqs[-1]],
        cmap="magma", vmin=vmin, vmax=vmax, interpolation="nearest",
    )
    axes[1, 0].set_title(r"Spectrogram $S_t$ (subwindow FFTs)")
    axes[1, 0].set_xlabel("Time within window (s)")
    axes[1, 0].set_ylabel("Frequency (Hz)")
    im1 = axes[1, 1].imshow(
        S1, origin="lower", aspect="auto",
        extent=[times1[0], times1[-1], freqs[0], freqs[-1]],
        cmap="magma", vmin=vmin, vmax=vmax, interpolation="nearest",
    )
    axes[1, 1].set_title(r"Spectrogram $S_{t+1}$ (prediction target)")
    axes[1, 1].set_xlabel("Time within window (s)")
    for ax in axes[1]:
        style_ax(ax)
        ax.axhline(85, color="cyan", ls="--", lw=0.9, alpha=0.85)
        ax.text(0.02, 95, "defect band ~85 Hz", color="cyan", fontsize=8,
                transform=ax.get_yaxis_transform())

    cbar = fig.colorbar(im1, ax=axes[1, :].ravel().tolist(), fraction=0.025, pad=0.02)
    cbar.set_label(r"$\log(1+|X|)$", fontsize=9)
    fig.suptitle("From vibration waveforms to consecutive spectrograms", fontsize=12, y=0.995)
    fig.tight_layout(rect=[0, 0, 0.98, 0.97])
    fig.savefig(OUT / "fig_signal_spectrograms.pdf")
    fig.savefig(OUT / "fig_signal_spectrograms.png")
    plt.close(fig)


def fig3_prediction_concept():
    _, x0 = synth_window(0.0, alpha_end=0.40, seed=4)
    _, x1 = synth_window(TW, alpha_end=0.75, seed=5)
    times, freqs, S0 = log_spectrogram(x0)
    _, _, S1 = log_spectrogram(x1)
    # fake prediction: blend toward truth with slight blur/underestimate
    Sp = 0.15 * S0 + 0.85 * S1
    Sp = Sp + 0.03 * np.random.default_rng(0).standard_normal(Sp.shape)
    residual = np.abs(S1 - Sp)

    fig = plt.figure(figsize=(8.4, 6.4), dpi=160)
    gs = gridspec.GridSpec(2, 2, height_ratios=[1.2, 1.0], hspace=0.35, wspace=0.25)
    ax0 = fig.add_subplot(gs[0, 0])
    ax1 = fig.add_subplot(gs[0, 1])
    ax2 = fig.add_subplot(gs[1, 0])
    ax3 = fig.add_subplot(gs[1, 1])

    vmin = min(S0.min(), S1.min(), Sp.min())
    vmax = max(S0.max(), S1.max(), Sp.max())
    extent = [times[0], times[-1], freqs[0], freqs[-1]]
    for ax, S, title in [
        (ax0, S0, r"Input $S_t$"),
        (ax1, Sp, r"DNN prediction $\hat{S}_{t+1}$"),
        (ax2, S1, r"True $S_{t+1}$"),
        (ax3, residual, r"Residual $|S_{t+1}-\hat{S}_{t+1}|$"),
    ]:
        cmap = "magma" if ax is not ax3 else "viridis"
        im = ax.imshow(S, origin="lower", aspect="auto", extent=extent,
                       cmap=cmap, vmin=(vmin if ax is not ax3 else None),
                       vmax=(vmax if ax is not ax3 else None), interpolation="nearest")
        ax.set_title(title, fontsize=10)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Frequency (Hz)")
        style_ax(ax)
        fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    fig.suptitle("Next-window spectrogram prediction and residual map (illustrative)", fontsize=12)
    fig.savefig(OUT / "fig_prediction_residual.pdf", bbox_inches="tight")
    fig.savefig(OUT / "fig_prediction_residual.png", bbox_inches="tight")
    plt.close(fig)


def fig4_stft_columns():
    """Show a few subwindow spectra as columns building a spectrogram."""
    _, x = synth_window(0.0, alpha_end=0.55, seed=6)
    times, freqs, S = log_spectrogram(x)
    fig, axes = plt.subplots(1, 3, figsize=(8.4, 3.0), dpi=160)
    for ax, m, title in [
        (axes[0], 0, "Early subwindow FFT"),
        (axes[1], len(times) // 2, "Mid subwindow FFT"),
        (axes[2], len(times) - 1, "Late subwindow FFT"),
    ]:
        ax.plot(freqs, S[:, m], color="#1f4e79", lw=1.0)
        ax.fill_between(freqs, S[:, m], color="#1f4e79", alpha=0.15)
        ax.set_xlim(0, FMAX)
        ax.set_xlabel("Frequency (Hz)")
        ax.set_ylabel(r"$\log(1+|X|)$")
        ax.set_title(title, fontsize=10)
        style_ax(ax)
    fig.suptitle("Subwindow FFTs that are stacked into the spectrogram", fontsize=11, y=1.02)
    fig.tight_layout()
    fig.savefig(OUT / "fig_subwindow_ffts.pdf", bbox_inches="tight")
    fig.savefig(OUT / "fig_subwindow_ffts.png", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    fig1_signal_and_subwindows()
    fig2_spectrogram_current_next()
    fig3_prediction_concept()
    fig4_stft_columns()
    print("Wrote figures to", OUT)
    for p in sorted(OUT.glob("fig_*.pdf")):
        print(" ", p.name)
