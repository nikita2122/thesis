"""
Generate all experimental result figures for the doctoral thesis.
All numeric values are PLACEHOLDER data for illustrative purposes.

Outputs PDF files to the same directory as this script.
"""

from __future__ import annotations

import os

import matplotlib.pyplot as plt
import numpy as np

# ---------------------------------------------------------------------------
# Global style (thesis-ready)
# ---------------------------------------------------------------------------
OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
FONT_SIZE = 11
TITLE_SIZE = 12
LINE_WIDTH = 2.0
MARKER_SIZE = 7

plt.rcParams.update(
    {
        "font.size": FONT_SIZE,
        "axes.titlesize": TITLE_SIZE,
        "axes.labelsize": FONT_SIZE,
        "xtick.labelsize": FONT_SIZE - 1,
        "ytick.labelsize": FONT_SIZE - 1,
        "legend.fontsize": FONT_SIZE - 1,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "axes.grid": True,
        "grid.alpha": 0.35,
        "grid.linestyle": "--",
    }
)

COLORS = {
    "ae": "#4C72B0",
    "dae": "#55A868",
    "sae": "#C44E52",
    "dsae": "#8172B3",
    "best": "#1F77B4",
    "avg": "#FF7F0E",
    "primary": "#2C5F8A",
    "secondary": "#D95F02",
    "accent": "#1B9E77",
}


def _save(fig: plt.Figure, name: str) -> None:
    path = os.path.join(OUTPUT_DIR, name)
    fig.savefig(path, format="pdf")
    plt.close(fig)
    print(f"Saved {path}")


# ---------------------------------------------------------------------------
# Fig 5.1 — Noise robustness (multi-line)
# ---------------------------------------------------------------------------
def plot_noise_robustness() -> None:
    noise_levels = np.array([0, 5, 10, 15, 20])  # percent

    # PLACEHOLDER: DSAE degrades more slowly than baselines
    ae = np.array([0.840, 0.805, 0.752, 0.698, 0.631])
    dae = np.array([0.870, 0.848, 0.812, 0.765, 0.710])
    sae = np.array([0.860, 0.835, 0.798, 0.748, 0.685])
    dsae = np.array([0.910, 0.898, 0.882, 0.861, 0.835])

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(
        noise_levels, ae, "o-", color=COLORS["ae"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="AE",
    )
    ax.plot(
        noise_levels, dae, "s-", color=COLORS["dae"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="DAE",
    )
    ax.plot(
        noise_levels, sae, "^-", color=COLORS["sae"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="SAE",
    )
    ax.plot(
        noise_levels, dsae, "D-", color=COLORS["dsae"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="DSAE (proposed)",
    )

    ax.set_xlabel("Noise level (%)")
    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Classification Performance vs. Input Noise Level")
    ax.set_xlim(-1, 21)
    ax.set_ylim(0.60, 0.95)
    ax.set_xticks(noise_levels)
    ax.legend(loc="lower left", framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig5_1_noise_robustness.pdf")


# ---------------------------------------------------------------------------
# Fig 5.2 — Sparsity sensitivity (single line)
# ---------------------------------------------------------------------------
def plot_sparsity_sensitivity() -> None:
    lambda_s = np.array([0.0, 0.001, 0.005, 0.01, 0.05, 0.1, 0.5])

    # PLACEHOLDER: peak around lambda_s = 0.01
    macro_f1 = np.array([0.875, 0.888, 0.902, 0.910, 0.898, 0.872, 0.831])

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(
        lambda_s, macro_f1, "o-", color=COLORS["dsae"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="DSAE",
    )
    ax.axvline(0.01, color="gray", linestyle=":", alpha=0.7, label=r"Selected $\lambda_s = 0.01$")

    ax.set_xlabel(r"Sparsity coefficient $\lambda_s$")
    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Effect of Sparsity Regularization on DSAE Performance")
    ax.set_xscale("log")
    ax.set_ylim(0.80, 0.93)
    ax.legend(loc="lower left", framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig5_2_sparsity_sensitivity.pdf")


# ---------------------------------------------------------------------------
# Fig 5.3 — Latent dimension study (line + optional secondary axis)
# ---------------------------------------------------------------------------
def plot_latent_dimension() -> None:
    latent_dims = np.array([32, 64, 128, 256])

    # PLACEHOLDER
    macro_f1 = np.array([0.882, 0.910, 0.905, 0.898])
    train_time_min = np.array([18.5, 24.3, 38.7, 67.2])

    fig, ax1 = plt.subplots(figsize=(7, 4.5))
    ax1.plot(
        latent_dims, macro_f1, "o-", color=COLORS["primary"], lw=LINE_WIDTH,
        ms=MARKER_SIZE, label="Macro-F1",
    )
    ax1.set_xlabel("Latent dimension $d$")
    ax1.set_ylabel("Macro-F1 score", color=COLORS["primary"])
    ax1.set_xticks(latent_dims)
    ax1.set_ylim(0.86, 0.93)
    ax1.tick_params(axis="y", labelcolor=COLORS["primary"])

    ax2 = ax1.twinx()
    ax2.plot(
        latent_dims, train_time_min, "s--", color=COLORS["secondary"],
        lw=LINE_WIDTH, ms=MARKER_SIZE, label="Training time",
    )
    ax2.set_ylabel("Training time (min)", color=COLORS["secondary"])
    ax2.tick_params(axis="y", labelcolor=COLORS["secondary"])

    ax1.set_title("Latent Dimension vs. Performance and Training Cost")
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="center right", framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig5_3_latent_dimension.pdf")


# ---------------------------------------------------------------------------
# Fig 5.4 — GA convergence (best + average fitness)
# ---------------------------------------------------------------------------
def plot_ga_convergence() -> None:
    generations = np.arange(1, 51)

    # PLACEHOLDER: logistic-style convergence
    best = 0.72 + 0.21 / (1 + np.exp(-0.18 * (generations - 18)))
    avg = best - 0.06 * np.exp(-0.12 * generations) - 0.015

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(
        generations, best, "-", color=COLORS["best"], lw=LINE_WIDTH,
        label="Best fitness",
    )
    ax.plot(
        generations, avg, "-", color=COLORS["avg"], lw=LINE_WIDTH,
        label="Average fitness",
    )

    ax.set_xlabel("Generation")
    ax.set_ylabel("Fitness (Macro-F1)")
    ax.set_title("GA Convergence During DNN Architecture Optimization")
    ax.set_xlim(1, 50)
    ax.set_ylim(0.68, 0.96)
    ax.legend(loc="lower right", framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig5_4_ga_convergence.pdf")


# ---------------------------------------------------------------------------
# Fig 5.5 — Progressive sensor fusion (ordinal line)
# ---------------------------------------------------------------------------
def plot_sensor_fusion() -> None:
    configs = ["Vibration\nonly", "Vibration\n+ Noise", "Vibration\n+ Noise\n+ Temp."]
    x = np.arange(len(configs))

    # PLACEHOLDER
    macro_f1 = np.array([0.862, 0.891, 0.910])

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(
        x, macro_f1, "o-", color=COLORS["accent"], lw=LINE_WIDTH,
        ms=MARKER_SIZE + 1,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(configs)
    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Progressive Multi-Sensor Feature Fusion")
    ax.set_ylim(0.84, 0.93)
    for xi, yi in zip(x, macro_f1):
        ax.annotate(
            f"{yi:.3f}", (xi, yi), textcoords="offset points",
            xytext=(0, 10), ha="center", fontsize=FONT_SIZE - 1,
        )
    fig.tight_layout()
    _save(fig, "fig5_5_sensor_fusion.pdf")


# ---------------------------------------------------------------------------
# Fig 5.6 — Ablation progression (ordinal line)
# ---------------------------------------------------------------------------
def plot_ablation_progression() -> None:
    variants = [
        "Baseline",
        "+ DSAE",
        "+ Attention",
        "+ Fusion",
        "+ GA-DNN",
    ]
    x = np.arange(len(variants))

    # PLACEHOLDER: incremental gains
    macro_f1 = np.array([0.782, 0.858, 0.881, 0.902, 0.930])

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(
        x, macro_f1, "o-", color=COLORS["primary"], lw=LINE_WIDTH,
        ms=MARKER_SIZE + 1,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(variants, rotation=15, ha="right")
    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Ablation Study: Incremental Component Contribution")
    ax.set_ylim(0.74, 0.96)
    for xi, yi in zip(x, macro_f1):
        ax.annotate(
            f"{yi:.3f}", (xi, yi), textcoords="offset points",
            xytext=(0, 10), ha="center", fontsize=FONT_SIZE - 1,
        )
    fig.tight_layout()
    _save(fig, "fig5_6_ablation_progression.pdf")


# ---------------------------------------------------------------------------
# Fig 5.7 — AE family comparison (bar chart)
# ---------------------------------------------------------------------------
def plot_ae_comparison() -> None:
    models = ["AE", "DAE", "SAE", "DSAE"]
    macro_f1 = [0.840, 0.870, 0.860, 0.910]  # PLACEHOLDER
    colors = [COLORS["ae"], COLORS["dae"], COLORS["sae"], COLORS["dsae"]]

    fig, ax = plt.subplots(figsize=(6.5, 4.5))
    bars = ax.bar(models, macro_f1, color=colors, edgecolor="black", linewidth=0.6)
    ax.bar_label(bars, fmt="%.3f", padding=3, fontsize=FONT_SIZE - 1)

    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Autoencoder Variant Comparison")
    ax.set_ylim(0.80, 0.95)
    fig.tight_layout()
    _save(fig, "fig5_7_ae_comparison.pdf")


# ---------------------------------------------------------------------------
# Fig 5.8 — Attention on/off (bar chart)
# ---------------------------------------------------------------------------
def plot_attention_comparison() -> None:
    conditions = ["DSAE only", "DSAE + Attention"]
    macro_f1 = [0.898, 0.910]  # PLACEHOLDER

    fig, ax = plt.subplots(figsize=(5.5, 4.5))
    bars = ax.bar(
        conditions, macro_f1,
        color=[COLORS["dsae"], COLORS["accent"]],
        edgecolor="black", linewidth=0.6, width=0.55,
    )
    ax.bar_label(bars, fmt="%.3f", padding=3, fontsize=FONT_SIZE - 1)

    ax.set_ylabel("Macro-F1 score")
    ax.set_title("Effect of Attention-Based Feature Refinement")
    ax.set_ylim(0.87, 0.93)
    fig.tight_layout()
    _save(fig, "fig5_8_attention_comparison.pdf")


# ---------------------------------------------------------------------------
# Fig 5.9 — Confusion matrix (heatmap)
# ---------------------------------------------------------------------------
def plot_confusion_matrix() -> None:
    class_names = [
        "Normal", "Bearing", "Imbalance", "Misalign",
        "Looseness", "Gear", "Lubrication", "Cavitation",
    ]

    # PLACEHOLDER: 8x8 confusion matrix (rows=true, cols=predicted)
    cm = np.array([
        [142,   2,   1,   1,   0,   1,   0,   0],
        [  3, 135,   2,   1,   1,   0,   1,   0],
        [  1,   2, 138,   2,   1,   0,   0,   1],
        [  2,   1,   3, 134,   2,   1,   0,   0],
        [  0,   1,   1,   2, 139,   1,   1,   0],
        [  1,   0,   0,   1,   1, 136,   2,   2],
        [  0,   1,   0,   0,   2,   1, 140,   1],
        [  1,   0,   1,   0,   0,   2,   1, 138],
    ], dtype=float)

    row_sums = cm.sum(axis=1, keepdims=True)
    cm_norm = cm / row_sums

    fig, ax = plt.subplots(figsize=(8.5, 7))
    im = ax.imshow(cm_norm, cmap="Blues", vmin=0, vmax=1)

    ax.set_xticks(np.arange(len(class_names)))
    ax.set_yticks(np.arange(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted class")
    ax.set_ylabel("True class")
    ax.set_title("Confusion Matrix — Proposed System (Test Set)")

    for i in range(len(class_names)):
        for j in range(len(class_names)):
            val = int(cm[i, j])
            color = "white" if cm_norm[i, j] > 0.55 else "black"
            ax.text(j, i, str(val), ha="center", va="center", color=color, fontsize=9)

    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("Normalized count")
    fig.tight_layout()
    _save(fig, "fig5_9_confusion_matrix.pdf")


# ---------------------------------------------------------------------------
# Fig 5.10 — GA vs fixed DNN (grouped bar)
# ---------------------------------------------------------------------------
def plot_ga_vs_fixed() -> None:
    configurations = ["Config A", "Config B", "Config C"]
    x = np.arange(len(configurations))
    width = 0.35

    # PLACEHOLDER
    fixed_dnn = np.array([0.862, 0.878, 0.855])
    ga_optimized = np.array([0.901, 0.918, 0.893])

    fig, ax = plt.subplots(figsize=(7, 4.5))
    bars1 = ax.bar(
        x - width / 2, fixed_dnn, width, label="Fixed DNN",
        color=COLORS["ae"], edgecolor="black", linewidth=0.6,
    )
    bars2 = ax.bar(
        x + width / 2, ga_optimized, width, label="GA-optimized DNN",
        color=COLORS["dsae"], edgecolor="black", linewidth=0.6,
    )
    ax.bar_label(bars1, fmt="%.3f", padding=2, fontsize=FONT_SIZE - 2)
    ax.bar_label(bars2, fmt="%.3f", padding=2, fontsize=FONT_SIZE - 2)

    ax.set_xticks(x)
    ax.set_xticklabels(configurations)
    ax.set_ylabel("Macro-F1 score")
    ax.set_title("GA-Optimized vs. Fixed DNN Classifier Architectures")
    ax.set_ylim(0.82, 0.95)
    ax.legend(loc="upper left", framealpha=0.9)
    fig.tight_layout()
    _save(fig, "fig5_10_ga_vs_fixed.pdf")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    plot_noise_robustness()
    plot_sparsity_sensitivity()
    plot_latent_dimension()
    plot_ga_convergence()
    plot_sensor_fusion()
    plot_ablation_progression()
    plot_ae_comparison()
    plot_attention_comparison()
    plot_confusion_matrix()
    plot_ga_vs_fixed()

    print(f"\nAll 10 figures generated in {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
