"""
Numerical estimation study for a variable-speed hydro-generator.

The plant is a lumped benchmark assembled from published parameter ranges
(not measurements from a named station). Three controllers are compared,
and a physics-based extended Kalman filter plus a small trained residual
network estimates hot-spot temperature, eccentricity and cooling health.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures"
FIG.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Benchmark parameters (120 MW class, variable-speed synchronous unit)
# ---------------------------------------------------------------------------
P = dict(
    H=4.0,
    D=0.6,
    Tw=1.7,
    Ty=0.55,
    Td0=2.4,
    At=1.08,
    qnl=0.05,
    kf=0.015,
    hres=1.015,
    g0=18.0,
    kmag=8.2,
    kunb=0.45,
    tau_e=18.0,
    Rth=26.0,
    Cth=6.5,
    Tcool=34.0,
    Pcu0=1.55,
    Pfe=0.50,
    Pstr=0.25,
    alpha=0.0039,
    Tref_loss=105.0,
    half_deg=8.0,
    sigma0=0.30,
    kq=0.11,
    ky=0.35,
    sigma_min=0.145,
    eta_max=0.945,
    Ibase=1.0,
)


def clip(x, lo, hi):
    return np.minimum(np.maximum(x, lo), hi)


def sigma_of(q, y):
    return P["sigma0"] - P["kq"] * q**2 - P["ky"] * np.maximum(0.0, y - 0.82) ** 2


def losses(Ipu, T):
    pcu = P["Pcu0"] * Ipu**2 * (1.0 + P["alpha"] * (T - 75.0))
    return pcu + P["Pfe"] + P["Pstr"]


def hotspot(T, Ipu, xi):
    return T + 4.0 + 9.5 * Ipu**2 + 16.0 * (1.0 - xi)


def wopt(q):
    return clip(0.90 + 0.12 * (q - 0.65), 0.86, 1.10)


def efficiency(q, omega, Ipu, T):
    et = P["eta_max"] * np.exp(-0.5 * ((omega - wopt(q)) / 0.14) ** 2)
    et *= np.exp(-0.5 * ((q - 0.84) / 0.30) ** 2)
    eg = 0.987 - 0.010 * (Ipu - 0.75) ** 2 - 0.003 * np.maximum(0.0, T - 80.0) / 25.0
    return clip(et * eg, 0.2, 0.99)


def aging_rate(Ths):
    """Equivalent seconds at Tref per second of operation (Montsinger-style)."""
    return 2.0 ** ((Ths - P["Tref_loss"]) / P["half_deg"])


def pm_of(h, q, omega):
    return P["At"] * h * (q - P["qnl"]) * (1.0 - 0.15 * (omega - 1.0))


def deriv(x, u, bow):
    omega, Eq, y, q, T, ex, ey, xi, life = x
    ycmd, Efd, Iq = u
    ycmd = clip(ycmd, 0.25, 1.05)
    Efd = clip(Efd, 0.4, 2.2)
    Iq = clip(Iq, 0.05, 1.35)
    h = (q / max(y, 0.20)) ** 2
    Pm = pm_of(h, q, omega)
    Pe = Eq * Iq
    Ipu = abs(Iq)  # Id held near 0 by the stator converter
    domega = (Pm - Pe - P["D"] * (omega - 1.0)) / (2.0 * P["H"])
    dEq = (Efd - Eq) / P["Td0"]
    dy = (ycmd - y) / P["Ty"]
    dq = (P["hres"] - h - P["kf"] * q * abs(q)) / P["Tw"]
    Pl = losses(Ipu, T)
    dT = (Pl - (T - P["Tcool"]) / (P["Rth"] * max(xi, 0.35))) / P["Cth"]
    amp = P["kmag"] * Eq**2 / P["g0"]
    unb = P["kunb"] * (omega**2 - 1.0)
    dex = (bow[0] + amp * ex + unb - ex) / P["tau_e"]
    dey = (bow[1] + amp * ey - ey) / P["tau_e"]
    dxi = 0.0  # xi is an exogenous health input integrated outside
    Ths = hotspot(T, Ipu, xi)
    dlife = aging_rate(Ths)
    return np.array([domega, dEq, dy, dq, dT, dex, dey, dxi, dlife], dtype=float)


def rk4(x, u, bow, dt):
    k1 = deriv(x, u, bow)
    k2 = deriv(x + 0.5 * dt * k1, u, bow)
    k3 = deriv(x + 0.5 * dt * k2, u, bow)
    k4 = deriv(x + dt * k3, u, bow)
    xn = x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
    xn[0] = clip(xn[0], 0.7, 1.25)
    xn[1] = clip(xn[1], 0.3, 2.0)
    xn[2] = clip(xn[2], 0.2, 1.08)
    xn[3] = clip(xn[3], 0.15, 1.3)
    xn[4] = clip(xn[4], 5.0, 180.0)
    xn[5] = clip(xn[5], -15.0, 15.0)
    xn[6] = clip(xn[6], -15.0, 15.0)
    xn[7] = clip(xn[7], 0.35, 1.0)
    return xn


def observables(x, Iq):
    omega, Eq, y, q, T, ex, ey, xi, life = x
    Ipu = abs(Iq)
    Ths = hotspot(T, Ipu, xi)
    e = np.hypot(ex, ey)
    sig = sigma_of(q, y)
    eta = efficiency(q, omega, Ipu, T)
    Pe = Eq * Iq
    h = (q / max(y, 0.20)) ** 2
    Pm = pm_of(h, q, omega)
    return dict(Ipu=Ipu, Ths=Ths, e=e, sigma=sig, eta=eta, Pe=Pe, Pm=Pm, h=h)


# ---------------------------------------------------------------------------
# Controllers
# ---------------------------------------------------------------------------
def targets_from_power(Pset):
    """Approximate efficient (q, omega, y) consistent with a power request."""
    q = clip(0.55 + 0.38 * Pset, 0.45, 1.05)
    w = float(wopt(q))
    # h ≈ (q/y)^2, Pm ≈ At*h*(q-qnl) ≈ Pset at omega~1
    # choose y so that h = Pset / (At*(q-qnl))
    h_need = Pset / max(P["At"] * (q - P["qnl"]), 0.15)
    h_need = clip(h_need, 0.55, 1.15)
    y = clip(q / np.sqrt(h_need), 0.4, 1.02)
    return q, w, y


class PIDCtrl:
    """Fixed-speed droop governor. Electrical torque holds speed near 1.0 pu.

    The gate follows power. Field voltage is held high and constant. There is
    no efficiency ridge, no cavitation back-off and no wear feedback.
    """

    def __init__(self):
        self.iy = 0.75

    def reset(self, Pset):
        self.iy = clip(0.48 + 0.50 * Pset, 0.4, 1.0)

    def act(self, x, Pset, ffr, est, dt):
        omega, Eq, y, q = x[0], x[1], x[2], x[3]
        # Fast electrical loop locks speed. Positive speed error increases load.
        Pdem = clip((Pset + ffr) + 5.5 * (omega - 1.0), 0.25, 1.15)
        Iq = clip(Pdem / max(Eq, 0.55), 0.15, 1.25)
        # Gate supplies the mechanical power. A hard speed correction stops drift.
        y_star = clip(0.46 + 0.52 * (Pset + ffr) + 1.8 * (omega - 1.0), 0.38, 1.02)
        self.iy = clip(self.iy + dt * clip((y_star - self.iy) / 0.45, -0.12, 0.12), 0.35, 1.02)
        # Classical AVR holds a high internal voltage, which maximises magnetic pull.
        Efd = clip(1.18 + 2.5 * (1.18 - Eq), 0.7, 1.85)
        return np.array([self.iy, Efd, Iq])


class HydroCtrl:
    """Efficiency-seeking gate/speed/field law without thermal or eccentricity cost."""

    def __init__(self, wear=False):
        self.wear = wear
        self.iy = 0.7
        self.iq = 0.8
        self.efd = 1.0

    def reset(self, Pset):
        q, w, y = targets_from_power(Pset)
        self.iy = y
        self.iq = clip(Pset / 1.05, 0.2, 1.2)
        self.efd = 1.02

    def act(self, x, Pset, ffr, est, dt):
        omega, Eq, y, q, T = x[0], x[1], x[2], x[3], x[4]
        Ths = est["Ths"]
        e = est["e"]
        xi = est["xi"]
        Pdem = Pset + ffr
        # wear-aware derating uses the twin
        if self.wear:
            # Continuous derating. The fixed point is a lower power, not a trip.
            if Ths > 100.0:
                Pdem = Pdem / (1.0 + 0.045 * (Ths - 100.0))
            if e > 1.7:
                Pdem = Pdem / (1.0 + 0.08 * (e - 1.7))
            if xi < 0.90:
                Pdem = Pdem / (1.0 + 0.55 * (0.90 - xi))
            Pdem = clip(Pdem, 0.40, 1.15)
        q_star, w_star, y_star = targets_from_power(Pdem)
        # kinetic boost: if FFR requested, allow speed to fall and raise Iq first
        if ffr > 0.02:
            w_star = clip(w_star - 0.55 * ffr, 0.86, 1.08)
        # cavitation guard: shrink gate if predicted sigma is tight
        sig = sigma_of(q, y)
        if sig < P["sigma_min"] + 0.02:
            y_star = min(y_star, y - 0.01)
            q_star = min(q_star, q)
        y_star = clip(y_star + 1.6 * (w_star - omega), 0.35, 1.0)
        # move commands smoothly
        self.iy += dt * clip((y_star - self.iy) / 0.8, -0.08, 0.08)
        Iq_star = clip(Pdem / max(Eq, 0.5), 0.15, 1.25)
        # during FFR, Iq jumps faster
        rate = 0.8 if ffr > 0.02 else 0.35
        self.iq += dt * clip((Iq_star - self.iq) * rate, -0.25, 0.35)
        Eq_star = 1.00
        if self.wear and e > 1.5:
            Eq_star = clip(1.00 - 0.11 * (e - 1.5), 0.70, 1.00)
        if self.wear and Ths > 108.0:
            Eq_star = min(Eq_star, 0.86)
        self.efd += dt * clip((Eq_star - Eq) * 1.4, -0.3, 0.3)
        self.efd = clip(self.efd, 0.45, 1.7)
        return np.array([clip(self.iy, 0.3, 1.02), self.efd, clip(self.iq, 0.1, 1.3)])


# ---------------------------------------------------------------------------
# Estimator: EKF on a reduced physics model + residual net for the hot spot
# ---------------------------------------------------------------------------
NX = 8  # omega Eq y q T ex ey xi


def f_est(z, u, bow_hat, dt):
    x = np.zeros(9)
    x[:8] = z
    x[8] = 0.0
    xn = rk4(x, u, bow_hat, dt)
    return xn[:8]


def h_est(z, u):
    """Measurements: omega, Pe, y, q, T_rtd, ex, ey, pd_proxy."""
    omega, Eq, y, q, T, ex, ey, xi = z
    Iq = u[2]
    Ipu = abs(Iq)
    Pe = Eq * Iq
    # RTD sits below the true mean slightly and misses the hot spot
    Trtd = T - 1.5
    pd = 0.15 * np.maximum(0.0, hotspot(T, Ipu, xi) - 90.0) / 30.0 + 0.8 * (np.hypot(ex, ey) / P["g0"])
    return np.array([omega, Pe, y, q, Trtd, ex, ey, pd])


def numerical_jacobian(fun, z, eps=1e-4):
    y0 = fun(z)
    m = y0.size
    n = z.size
    J = np.zeros((m, n))
    for i in range(n):
        zp = z.copy()
        zp[i] += eps
        J[:, i] = (fun(zp) - y0) / eps
    return J


class EKF:
    def __init__(self):
        self.z = np.array([1.0, 1.0, 0.75, 0.8, 70.0, 0.4, 0.1, 0.95])
        self.Pz = np.diag([1e-4, 1e-3, 1e-4, 1e-4, 4.0, 0.05, 0.05, 0.01])
        self.Q = np.diag([1e-6, 1e-5, 1e-6, 1e-6, 0.02, 1e-4, 1e-4, 2e-5])
        self.R = np.diag([1e-5, 4e-4, 1e-5, 4e-4, 0.35, 0.02, 0.02, 0.01])
        self.bow = np.array([0.6, 0.15])

    def step(self, meas, u, dt, bow_meas_hint):
        # bow is not fully known: a low-pass of measured eccentricity provides a hint
        self.bow = 0.98 * self.bow + 0.02 * bow_meas_hint
        zpred = f_est(self.z, u, self.bow, dt)
        F = numerical_jacobian(lambda zz: f_est(zz, u, self.bow, dt), self.z)
        Pp = F @ self.Pz @ F.T + self.Q
        H = numerical_jacobian(lambda zz: h_est(zz, u), zpred)
        S = H @ Pp @ H.T + self.R
        K = Pp @ H.T @ np.linalg.inv(S)
        innov = meas - h_est(zpred, u)
        self.z = zpred + K @ innov
        self.z[0] = clip(self.z[0], 0.7, 1.25)
        self.z[1] = clip(self.z[1], 0.3, 2.0)
        self.z[2] = clip(self.z[2], 0.2, 1.08)
        self.z[3] = clip(self.z[3], 0.15, 1.3)
        self.z[4] = clip(self.z[4], 5.0, 180.0)
        self.z[7] = clip(self.z[7], 0.35, 1.0)
        I = np.eye(NX)
        self.Pz = (I - K @ H) @ Pp
        # symmetrize
        self.Pz = 0.5 * (self.Pz + self.Pz.T)
        return self.z


def make_features(T, Ipu, y, omega, e, pd):
    return np.array(
        [
            1.0,
            T / 100.0,
            Ipu**2,
            y,
            omega,
            e / 10.0,
            pd,
            (T / 100.0) * Ipu**2,
            pd * Ipu,
            e * Ipu / 10.0,
        ],
        dtype=float,
    )


def train_residual(seed=7):
    """Fit a linear map from measured features to hot-spot temperature.

    Training trajectories use the same plant with random set-points, cooling
    and bow, observed through the RTD and a PD proxy. This is the explicit
    regression stage of the twin; the EKF carries the dynamic physics.
    """
    rng = np.random.default_rng(seed)
    X, Y = [], []
    for _ in range(24):
        x = np.array([1.0, 1.0, 0.75, 0.78, 68.0, 0.3, 0.1, 1.0, 0.0])
        Pset = rng.uniform(0.5, 1.0)
        xi_tgt = rng.uniform(0.6, 1.0)
        bow = rng.normal(0.0, 0.8, size=2)
        Iq, Efd, ycmd = Pset / 1.05, 1.0, 0.75
        for k in range(800):
            x[7] += 0.002 * (xi_tgt - x[7])
            u = np.array([ycmd, Efd, Iq])
            x = rk4(x, u, bow, 0.2)
            if k % 10 == 0 and k > 100:
                ob = observables(x, Iq)
                Trtd = x[4] - 1.5 + rng.normal(0, 0.3)
                pd = 0.15 * max(0.0, ob["Ths"] - 90) / 30 + 0.8 * (ob["e"] / P["g0"])
                pd += rng.normal(0, 0.02)
                feat = make_features(Trtd, ob["Ipu"], x[2], x[0], ob["e"], pd)
                X.append(feat)
                Y.append(ob["Ths"])
            # random walk inputs
            if k % 40 == 0:
                Pset = clip(Pset + rng.normal(0, 0.08), 0.45, 1.05)
                Iq = clip(Pset / max(x[1], 0.6), 0.2, 1.2)
                ycmd = clip(0.5 + 0.4 * Pset + rng.normal(0, 0.02), 0.4, 1.0)
                Efd = clip(Efd + rng.normal(0, 0.05), 0.6, 1.5)
    X = np.asarray(X)
    Y = np.asarray(Y)
    lam = 1e-2
    A = X.T @ X + lam * np.eye(X.shape[1])
    w = np.linalg.solve(A, X.T @ Y)
    pred = X @ w
    rmse = float(np.sqrt(np.mean((pred - Y) ** 2)))
    return w, rmse, int(Y.size)


W_RES, TRAIN_RMSE, TRAIN_N = train_residual()


def ths_from_residual(Trtd, Ipu, y, omega, e, pd):
    feat = make_features(Trtd, Ipu, y, omega, e, pd)
    return float(feat @ W_RES)


# ---------------------------------------------------------------------------
# Scenarios
# ---------------------------------------------------------------------------
def scenario_inputs(name, t):
    """Return Pset, ffr, xi_cmd, bow."""
    if name == "S1":
        Pset = 0.55 if t < 30 else 0.92
        ffr = 0.0
        xi = 1.0
        bow = np.array([0.45, 0.10])
    elif name == "S2":
        Pset = 0.70
        ffr = 0.18 if 40 <= t < 70 else 0.0
        xi = 1.0
        bow = np.array([0.50, 0.12])
    elif name == "S3":
        Pset = 0.85
        ffr = 0.0
        xi = 1.0 if t < 40 else clip(1.0 - 0.0028 * (t - 40), 0.58, 1.0)
        grow = 0.0 if t < 40 else min(2.4, 0.010 * (t - 40))
        bow = np.array([0.70 + grow, 0.25])
    else:  # S4 combined
        Pset = 0.62 if t < 25 else 0.88
        ffr = 0.16 if 120 <= t < 150 else 0.0
        xi = 1.0 if t < 50 else clip(1.0 - 0.0024 * (t - 50), 0.60, 1.0)
        grow = 0.0 if t < 70 else min(2.2, 0.009 * (t - 70))
        bow = np.array([0.65 + grow, 0.20])
    return Pset, ffr, xi, bow


def run_case(name, ctrl, use_twin, dt=0.05, Tfinal=400.0, seed=1):
    rng = np.random.default_rng(seed)
    x = np.array([0.98, 1.02, 0.72, 0.70, 66.0, 0.40, 0.10, 1.0, 0.0])
    # settle 40 s under the initial controller before recording? include all
    Pset0, _, _, bow0 = scenario_inputs(name, 0.0)
    ctrl.reset(Pset0)
    ekf = EKF()
    n = int(Tfinal / dt)
    keys = [
        "t", "omega", "Eq", "y", "q", "T", "ex", "ey", "xi", "life",
        "Pe", "Pm", "Ths", "e", "sigma", "eta", "Pset", "ffr",
        "Ths_hat", "e_hat", "xi_hat", "T_hat",
    ]
    rec = {k: np.zeros(n) for k in keys}
    u = np.array([0.7, 1.0, 0.7])
    for k in range(n):
        t = k * dt
        Pset, ffr, xi_cmd, bow = scenario_inputs(name, t)
        x[7] += dt * (xi_cmd - x[7]) / 8.0
        ob = observables(x, u[2])
        # measurements
        noise = np.array(
            [
                rng.normal(0, 0.0004),
                rng.normal(0, 0.004),
                rng.normal(0, 0.001),
                rng.normal(0, 0.004),
                rng.normal(0, 0.25),
                rng.normal(0, 0.08),
                rng.normal(0, 0.08),
                rng.normal(0, 0.015),
            ]
        )
        Trtd = x[4] - 1.5
        pd = 0.15 * max(0.0, ob["Ths"] - 90) / 30 + 0.8 * (ob["e"] / P["g0"])
        meas = np.array([x[0], ob["Pe"], x[2], x[3], Trtd, x[5], x[6], pd]) + noise
        zhat = ekf.step(meas, u, dt, bow_hint_from_meas(meas))
        Ipu_h = abs(u[2])
        e_hat = float(np.hypot(zhat[5], zhat[6]))
        Trtd_hat = zhat[4] - 1.5
        pd_hat = meas[7]
        Ths_hat = ths_from_residual(meas[4], Ipu_h, meas[2], meas[0], e_hat, pd_hat)
        # blend physics hot-spot and residual
        Ths_phys = hotspot(zhat[4], Ipu_h, zhat[7])
        Ths_hat = 0.45 * Ths_hat + 0.55 * Ths_phys
        est = dict(Ths=Ths_hat if use_twin else ob["Ths"], e=e_hat if use_twin else ob["e"], xi=float(zhat[7]) if use_twin else x[7])
        if not use_twin:
            # wear-unaware controllers receive neutral health so they cannot cheat
            est = dict(Ths=70.0, e=0.3, xi=1.0)
        if k % 4 == 0:
            u = ctrl.act(x if not use_twin else _mix_state(x, zhat), Pset, ffr, est, dt * 4)
        x = rk4(x, u, bow, dt)
        rec["t"][k] = t
        rec["omega"][k] = x[0]
        rec["Eq"][k] = x[1]
        rec["y"][k] = x[2]
        rec["q"][k] = x[3]
        rec["T"][k] = x[4]
        rec["ex"][k] = x[5]
        rec["ey"][k] = x[6]
        rec["xi"][k] = x[7]
        rec["life"][k] = x[8]
        ob = observables(x, u[2])
        rec["Pe"][k] = ob["Pe"]
        rec["Pm"][k] = ob["Pm"]
        rec["Ths"][k] = ob["Ths"]
        rec["e"][k] = ob["e"]
        rec["sigma"][k] = ob["sigma"]
        rec["eta"][k] = ob["eta"]
        rec["Pset"][k] = Pset + ffr
        rec["ffr"][k] = ffr
        rec["Ths_hat"][k] = Ths_hat
        rec["e_hat"][k] = e_hat
        rec["xi_hat"][k] = zhat[7]
        rec["T_hat"][k] = zhat[4]
    return rec


def bow_hint_from_meas(meas):
    # measured ex, ey are indices 5, 6; static bow is a fraction of them
    return np.array([0.7 * meas[5], 0.7 * meas[6]])


def _mix_state(x, zhat):
    """Controller plant view: replace sensed states by estimates."""
    out = x.copy()
    out[0:8] = zhat
    return out


def metrics(rec):
    t = rec["t"]
    # ignore first 15 s
    m = t > 15
    life = rec["life"][m][-1] - rec["life"][m][0]
    return dict(
        eta_mean=float(np.mean(rec["eta"][m])),
        life_eq_s=float(life),
        Ths_max=float(np.max(rec["Ths"][m])),
        Ths_mean=float(np.mean(rec["Ths"][m])),
        e_max=float(np.max(rec["e"][m])),
        e_mean=float(np.mean(rec["e"][m])),
        sigma_min=float(np.min(rec["sigma"][m])),
        track_rmse=float(np.sqrt(np.mean((rec["Pe"][m] - rec["Pset"][m]) ** 2))),
        speed_rmse=float(np.sqrt(np.mean((rec["omega"][m] - wopt(rec["q"][m])) ** 2))),
        ths_rmse=float(np.sqrt(np.mean((rec["Ths_hat"][m] - rec["Ths"][m]) ** 2))),
        e_rmse=float(np.sqrt(np.mean((rec["e_hat"][m] - rec["e"][m]) ** 2))),
        xi_rmse=float(np.sqrt(np.mean((rec["xi_hat"][m] - rec["xi"][m]) ** 2))),
        T_rmse=float(np.sqrt(np.mean((rec["T_hat"][m] - rec["T"][m]) ** 2))),
        energy_mwh=float(np.trapezoid(rec["Pe"][m], t[m]) * 120.0 / 3600.0),
    )


def main():
    controllers = {
        "PID": (PIDCtrl(), False),
        "EFF": (HydroCtrl(wear=False), False),
        "WA": (HydroCtrl(wear=True), True),
    }
    scenarios = ["S1", "S2", "S3", "S4"]
    summary = {}
    store = {}
    for sc in scenarios:
        summary[sc] = {}
        for cname, (ctrl, twin) in controllers.items():
            print(f"running {sc} {cname}")
            rec = run_case(sc, ctrl, twin)
            summary[sc][cname] = metrics(rec)
            if sc == "S4":
                store[cname] = rec
            print(cname, summary[sc][cname])

    out = {
        "train_rmse_C": TRAIN_RMSE,
        "train_samples": TRAIN_N,
        "weights": W_RES.tolist(),
        "summary": summary,
        "plant": {k: (float(v) if np.ndim(v) == 0 else None) for k, v in P.items()},
    }
    # downsample S4 for optional external use
    (FIG / "summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    (ROOT / "sim" / "summary.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    plot_s4(store)
    plot_bars(summary)
    print("TRAIN_RMSE", TRAIN_RMSE, "N", TRAIN_N)
    print(json.dumps(summary, indent=2))


def plot_s4(store):
    t = store["WA"]["t"]
    step = 8
    sl = slice(None, None, step)
    fig, ax = plt.subplots(4, 1, figsize=(7.2, 8.6), sharex=True)
    for name, ls in (("PID", "--"), ("EFF", "-."), ("WA", "-")):
        ax[0].plot(t[sl], store[name]["Pe"][sl], ls, lw=1.3, label=name)
    ax[0].plot(t[sl], store["WA"]["Pset"][sl], "k:", lw=1.0, label="demand")
    ax[0].set_ylabel("Electrical power (pu)")
    ax[0].legend(ncol=4, fontsize=8, loc="lower right")
    ax[0].set_ylim(0.3, 1.25)
    ax[0].grid(True, alpha=0.3)

    for name, ls in (("PID", "--"), ("EFF", "-."), ("WA", "-")):
        ax[1].plot(t[sl], store[name]["Ths"][sl], ls, lw=1.3, label=name)
    ax[1].plot(t[sl], store["WA"]["Ths_hat"][sl], ":", color="C2", lw=1.2, label="WA estimate")
    ax[1].set_ylabel("Hot spot (°C)")
    ax[1].legend(ncol=4, fontsize=8)
    ax[1].grid(True, alpha=0.3)

    for name, ls in (("PID", "--"), ("EFF", "-."), ("WA", "-")):
        ax[2].plot(t[sl], store[name]["e"][sl], ls, lw=1.3, label=name)
    ax[2].plot(t[sl], store["WA"]["e_hat"][sl], ":", color="C2", lw=1.2, label="WA estimate")
    ax[2].set_ylabel("Eccentricity (mm)")
    ax[2].legend(ncol=4, fontsize=8)
    ax[2].grid(True, alpha=0.3)

    for name, ls in (("PID", "--"), ("EFF", "-."), ("WA", "-")):
        ax[3].plot(t[sl], store[name]["sigma"][sl], ls, lw=1.3, label=name)
    ax[3].axhline(P["sigma_min"], color="r", lw=0.8, ls=":")
    ax[3].set_ylabel("Thoma number")
    ax[3].set_xlabel("Time (s)")
    ax[3].legend(ncol=4, fontsize=8)
    ax[3].grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / "s4_timeseries.pdf")
    fig.savefig(FIG / "s4_timeseries.png", dpi=140)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 3.4))
    ax.plot(t[sl], store["WA"]["eta"][sl], label="WA efficiency")
    ax.plot(t[sl], store["EFF"]["eta"][sl], label="EFF efficiency")
    ax.plot(t[sl], store["PID"]["eta"][sl], label="PID efficiency")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Combined efficiency")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "s4_efficiency.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.2))
    m = store["WA"]["t"] > 15
    ax[0].plot(store["WA"]["Ths"][m][::8], store["WA"]["Ths_hat"][m][::8], ".", ms=2, alpha=0.5)
    lim0 = [
        min(store["WA"]["Ths"][m].min(), store["WA"]["Ths_hat"][m].min()),
        max(store["WA"]["Ths"][m].max(), store["WA"]["Ths_hat"][m].max()),
    ]
    ax[0].plot(lim0, lim0, "k-", lw=0.8)
    ax[0].set_xlabel("True hot spot (°C)")
    ax[0].set_ylabel("Estimated hot spot (°C)")
    ax[0].grid(True, alpha=0.3)
    ax[1].plot(store["WA"]["xi"][m][::8], label="true cooling health")
    ax[1].plot(store["WA"]["xi_hat"][m][::8], label="EKF estimate")
    ax[1].set_xlabel("Sample")
    ax[1].set_ylabel("Cooling health")
    ax[1].legend(fontsize=8)
    ax[1].grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / "estimation_scatter.pdf")
    plt.close(fig)


def plot_bars(summary):
    labels = ["S1", "S2", "S3", "S4"]
    controllers = ["PID", "EFF", "WA"]
    fig, ax = plt.subplots(1, 3, figsize=(7.4, 3.3))
    x = np.arange(len(labels))
    width = 0.25
    for i, c in enumerate(controllers):
        life = [summary[s][c]["life_eq_s"] for s in labels]
        emax = [summary[s][c]["e_max"] for s in labels]
        eta = [100 * summary[s][c]["eta_mean"] for s in labels]
        ax[0].bar(x + (i - 1) * width, eta, width, label=c)
        ax[1].bar(x + (i - 1) * width, life, width, label=c)
        ax[2].bar(x + (i - 1) * width, emax, width, label=c)
    ax[0].set_title("Mean efficiency (%)")
    ax[1].set_title("Aging (eq. s at 120°C)")
    ax[2].set_title("Peak eccentricity (mm)")
    for a in ax:
        a.set_xticks(x)
        a.set_xticklabels(labels)
        a.grid(True, axis="y", alpha=0.3)
    ax[0].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "metric_bars.pdf")
    plt.close(fig)


if __name__ == "__main__":
    main()
