import numpy as np
from estimate import PIDCtrl, scenario_inputs, rk4, observables

ctrl = PIDCtrl()
ctrl.reset(0.55)
x = np.array([0.98, 1.02, 0.72, 0.70, 66.0, 0.40, 0.10, 1.0, 0.0])
u = np.array([0.7, 1.0, 0.7])
dt = 0.05
for k in range(0, 1200):
    t = k * dt
    Pset, ffr, xi, bow = scenario_inputs("S1", t)
    est = dict(Ths=70, e=0.3, xi=1)
    if k % 4 == 0:
        u = ctrl.act(x, Pset, ffr, est, dt * 4)
    x = rk4(x, u, bow, dt)
    if k % 80 == 0:
        ob = observables(x, u[2])
        print(
            "t", round(t, 1),
            "w", round(x[0], 3),
            "Eq", round(x[1], 3),
            "y", round(x[2], 3),
            "q", round(x[3], 3),
            "Pe", round(ob["Pe"], 3),
            "Pm", round(ob["Pm"], 3),
            "Pset", Pset,
            "eta", round(ob["eta"], 3),
            "u", np.round(u, 3),
        )
