# Detailed Explanation of the Thesis

**Title:** Research for Improving Early Thermal Fault Detection and Predictive Maintenance of Hydro-Generators by Using Physics-Informed Deep Learning and Adaptive Graph Transformers

**Field:** Computer Science — System Design, Optimization, and Deep Learning for Industrial Monitoring

**Primary application:** Heat-sensor (RTD / thermocouple) data analysis for hydro-generator monitoring

---

## 1. What problem does the thesis solve?

Hydro-generators produce heat from copper losses, iron losses, and other electromagnetic/mechanical losses. Cooling systems remove that heat. When the balance breaks (blocked cooling, overload, insulation aging, local hotspots, bearing heating), temperature rises and accelerates further damage.

Plants already install heat sensors (mainly RTDs). In practice, monitoring is still weak because:

1. **Sensors are sparse.** A few dozen RTDs cannot show the full temperature field; true hotspots may sit between sensors.
2. **Threshold alarms are late.** A hard limit on one RTD reacts after the problem is already serious.
3. **Black-box ML ignores physics.** LSTM/ANN predictors can fit SCADA data but may produce non-physical fields and fail under regime shifts.
4. **Sensors are treated as independent channels.** Real thermal behavior is spatially coupled (neighboring slots, shared cooling loops).
5. **Remaining Useful Life (RUL)** for insulation is hard to estimate without credible hotspot temperature histories.

The thesis designs a **computer-science monitoring system** that improves early thermal fault detection and predictive maintenance using two complementary deep-learning innovations.

---

## 2. Overall thesis architecture

The solution is modular:

```
SCADA / CMS data
      │
      ▼
ETL + Feature Store
      │
      ├──► Innovation 1: PIST-TRN  (physics-informed thermal digital twin)
      │         │
      │         ├── reconstructed field / forecasts
      │         ├── hotspot temperature
      │         ├── physics residuals
      │         └── aging features
      │
      └──► Innovation 2: AMS-GT   (adaptive graph Transformer monitor)
                │
                ├── anomaly score + localization
                ├── health index
                └── RUL estimate
                      │
                      ▼
              Decision / Alert Manager → HMI (advisory only)
```

Important safety principle: AI outputs are **advisory**. Hard generator protection relays remain independent.

---

## 3. Innovation 1 — PIST-TRN

**Full name:** Physics-Informed Spatio-Temporal Thermal Reconstruction Network

### Idea
Build a real-time **thermal digital twin** that:
- fits sparse heat-sensor observations;
- obeys heat-transfer physics (Fourier heat equation, copper/iron losses, cooling boundaries);
- forecasts temperature over a horizon (e.g., 30–120 minutes);
- estimates unobserved **hotspot** temperatures;
- exports aging features for maintenance.

### Why it is innovative
Unlike pure LSTM/ANN temperature predictors, PIST-TRN embeds physics residuals into the learning loss. Unlike offline FEM, it runs online from SCADA covariates. It therefore combines **data fit + physical consistency + deployable speed**.

### Core technical pieces
- Temporal encoder over recent windows of temperatures and process inputs (power, current, coolant temperature, etc.).
- Fourier spatial encodings + thermal time-constant features.
- Residual MLP predicting continuous temperature \(T(x,t)\).
- Physics loss from heat-equation residual and Robin cooling boundaries.
- Adaptive collocation sampling where residuals are large.
- Ensemble uncertainty for confidence.

### What it outputs
- Sensor forecasts
- Hotspot estimate \(\hat{T}^{hs}\)
- Physics residual diagnostics
- Aging increment / equivalent aging temperature

### Typical reported gains (thesis estimation study)
- Better sensor RMSE than LSTM
- Much better hotspot RMSE (physics helps where sensors are missing)
- More robust under sensor dropout and season/regime shift

---

## 4. Innovation 2 — AMS-GT

**Full name:** Adaptive Multi-Sensor Graph Transformer

### Idea
Treat heat sensors and related process variables as a **graph**:
- nodes = RTDs, coolant, power/current, optional virtual hotspot from PIST-TRN;
- edges = spatial neighbors, shared cooling paths, electrical coupling, plus learned dynamic edges.

Then use:
- **graph attention** for spatial thermal coupling;
- **Transformer** layers for long temporal memory;
- dual heads for **anomaly detection** and **RUL**.

### Why it is innovative
Compared with threshold alarms and flat LSTM autoencoders, AMS-GT explicitly models sensor topology and adapts edges by operating regime (start-up vs full load vs cooling change). It also fuses physics-informed features from PIST-TRN instead of using raw channels alone.

### Core technical pieces
- Mixed static prior adjacency + dynamic attention adjacency
- Regime-aware gating of graph adaptivity
- Next-step prediction residual + latent shift anomaly score
- Node-wise localization scores
- Monotonic health index + RUL head
- Training curriculum: healthy self-supervision → physics-synthetic faults → scarce real events

### What it outputs
- Smoothed anomaly score and alarm decision
- Which sensors contributed most
- Edge saliency (which couplings changed)
- Health index and RUL

### Typical reported gains (thesis estimation study)
- Higher F1 at low false-positive rate
- Earlier lead time than thresholds / LSTM-AE
- Best RUL when fused with PIST-TRN aging/hotspot features

---

## 5. How the two innovations work together

They are complementary, not alternatives:

| Question | Answered by |
|----------|-------------|
| What is the temperature field, and how will it evolve under physics? | PIST-TRN |
| Which sensors/couplings are abnormal, and how much life remains? | AMS-GT |

Fusion modes:
1. **Independent:** AMS-GT on raw sensors only
2. **Feature fusion:** add hotspot/aging features from PIST-TRN
3. **Closed loop:** anomaly localization triggers denser physics residual audits in suspect regions

Best results in the thesis come from **feature fusion** (and closed-loop confirmation for local hotspots).

---

## 6. Thesis chapter map

### Chapter 1 — Previous work and problem set (~20 pages)
1. Research on physics-informed / thermal deep learning (foundation for Innovation 1)
2. Research on graph neural networks, Transformers, multi-sensor PHM (foundation for Innovation 2)
3. Formal problem set: reconstruction, anomaly detection, RUL, system constraints, hypotheses

### Chapter 2 — Methods (~30 pages)
1. Full design of PIST-TRN (architecture, losses, algorithms, complexity)
2. Full design of AMS-GT (graph construction, Transformer stack, multi-task training, fusion)

### Chapter 3 — System and estimation (~20 pages)
1. End-to-end system build (ETL, services, HMI, MLOps, safety)
2. Estimation study (accuracy, ablations, lead time, RUL, sparsity/noise/regime tests, latency)

---

## 7. Main evaluation claims (from the estimation study)

Against strong baselines (ANN/LSTM/PINN/LSTM-AE/static ST-GNN):

- **Reconstruction:** PIST-TRN best on sensors and especially hotspots
- **Detection:** fused AMS-GT best F1 and lead time at 1% false-positive rate
- **RUL:** fused model lowest MAPE / prognostics score
- **Latency:** end-to-end ~0.12 s P95 — fine for 30–60 s SCADA sampling
- **Robustness:** better under missing sensors and cooling-season shift

These support hypotheses H1–H4 in the thesis.

---

## 8. What is *not* claimed

- Not a redesign of generator hardware
- Not a replacement for protection relays
- RUL numbers rely partly on physics-based surrogate aging trajectories because true run-to-failure insulation labels are scarce
- Absolute metrics must be re-validated on each plant’s data

---

## 9. Related short papers

Two companion short papers extract each innovation:

1. **`paper1/`** — short paper on **PIST-TRN** (physics-informed thermal reconstruction)
2. **`paper2/`** — short paper on **AMS-GT** (adaptive graph Transformer monitoring)

Each folder contains LaTeX sources, a compiled PDF, and a TXT extract.

---

## 10. How to rebuild everything

### Full thesis
```bash
cd main
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

### Paper 1
```bash
cd paper1
pdflatex main.tex
pdflatex main.tex
```

### Paper 2
```bash
cd paper2
pdflatex main.tex
pdflatex main.tex
```

---

## 11. One-paragraph “elevator pitch”

This thesis improves hydro-generator thermal monitoring by combining a physics-informed deep thermal twin (PIST-TRN) that reconstructs and forecasts temperature fields from sparse heat sensors with an adaptive multi-sensor graph Transformer (AMS-GT) that detects anomalies early and estimates insulation-oriented remaining useful life. Together they form a deployable, explainable, advisory monitoring system that outperforms threshold logic and black-box deep learning alone.
